Important Notes Languages

Unzip the downloaded file.

The languages are installed directly in Cinema 4D. To install, select the "Manual Installation" command from the Cinema 4D "Help" menu.

Cinema 4D will prompt you to select the .c4dupdate package to install.

Once you have selected a language to install the Online Updater dialog window will open. Confirm your choice by again selecting the language you want to install either in the "Update" or "Optional" tab's dialog. Click on the "Install Now" button to proceed and follow the instructions that appear to complete the installation.

You now have access to the new installed language.